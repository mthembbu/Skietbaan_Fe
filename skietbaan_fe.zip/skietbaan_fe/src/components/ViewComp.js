import React, { Component } from 'react'

export default class ViewComp extends Component {
    constructor(props){
        super(props);

    }
//The method that renders the view competition    
  render() {
    return (
      <div>
        <h1>The view competition page</h1>
      </div>
    )
  }
}
