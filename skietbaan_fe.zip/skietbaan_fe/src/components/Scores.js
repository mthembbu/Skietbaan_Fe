import React, { Component } from 'react'

class scorecapture extends Component {
  render() {
    return (
      <div>
        <h1>score</h1>
      </div>
    )
  }
}

export default scorecapture;