export const ADD_BOOKMARK = 'ADD_BOOKMARK';
export const DELETE_BOOKMARK = 'DELETE_BOOKMARK';
export const FETCH_POSTS = 'FETCH_POSTS';
export const NEW_POST = 'NEW_POST';
export const NEW_COMP = 'NEW_COMP';
export const FETCH_COMP = 'NEW_COMP';
export const BASE_URL = "https://api.skietbaan.retrotest.co.za";
//leaderboard types
export const FETCH_LEADERBOARDFILTER_DATA = 'FETCH_LEADERBOARDFILTER_DATA';
export const FETCH_LEADERBOARDTABLE_DATA = 'FETCH_LEADERBOARDTABLE_DATA';
export const URL = "https://api.skietbaan.retrotest.co.za"; 
// export const URLADD = "https://api.skietbaan.retrotest.co.za/api/groups/add"; 
// export const URLUSER = "https://api.skietbaan.retrotest.co.za/api/user"; 
// export const URLGROUP = "https://api.skietbaan.retrotest.co.za/api/groups"; 
export const URLADD = "http://localhost:63474/api/groups/add"; 
export const URLUSER = "http://localhost:63474/api/user"; 
export const URLGROUP = "http://localhost:63474/api/groups"; 
export const UPDATENAME = 'UPDATENAME';
export const CREATEGROUP = 'CREATEGROUP';
export const GETGROUP = 'GETGROUP';
export const PASS_ID = 'PASS_ID';
export const GETNAME = 'GETNAME';

FETCH_LEADERBOARDFILTER_DATA